<Div class="content_wrap normal" style="height:100%;position:absolute;width:100%;">
<div class="mobile_body"></div>
</Div>