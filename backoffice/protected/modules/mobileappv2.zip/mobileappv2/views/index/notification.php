

<div class="card" id="box_wrap">
<div class="card-body">

<ul class="list-group notification_list">  
</ul>

</div> <!--card body-->
</div> <!--card-->
