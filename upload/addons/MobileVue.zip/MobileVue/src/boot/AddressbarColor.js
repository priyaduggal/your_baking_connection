import { boot } from "quasar/wrappers";
import { AddressbarColor } from "quasar";

export default () => {
  AddressbarColor.set("#ff724c");
};
