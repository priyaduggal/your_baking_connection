<template>
  <div>My SearchFood</div>
</template>

<script>
export default {
  name: 'SearchFood',
  setup () {
    return {}
  }
}
</script>
