<template>
  <div>My SearchResto</div>
</template>

<script>
export default {
  name: 'SearchResto',
  setup () {
    return {}
  }
}
</script>
