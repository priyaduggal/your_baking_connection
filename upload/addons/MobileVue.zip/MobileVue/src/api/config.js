const config = {
  api_base_url: "",
  api_payment_url: "",
  api_token: "",
  google_client_id: "46158489047-vptkm75h1okppmo5k0btqor6n8hki0dp.apps.googleusercontent.com",
  facebook_app_id: "361247692401530",
  topic: "customer",
  channel: "krms-channel",
  sound: "notify.mp3",
};
export default config;
